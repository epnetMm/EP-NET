// Initialize Feather icons when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
  // Initialize Feather icons
  feather.replace();
  
  // Initialize all tooltips
  var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
  var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
    return new bootstrap.Tooltip(tooltipTriggerEl);
  });
  
  // Add event listener for copy buttons
  document.querySelectorAll('[data-copy]').forEach(button => {
    button.addEventListener('click', function() {
      const textToCopy = this.getAttribute('data-copy');
      copyToClipboard(textToCopy);
    });
  });
});

// Function to copy text to clipboard
function copyToClipboard(text) {
  // Create a temporary input element
  const input = document.createElement('input');
  input.style.position = 'fixed';
  input.style.opacity = 0;
  input.value = text;
  document.body.appendChild(input);
  
  // Select and copy the text
  input.select();
  document.execCommand('copy');
  
  // Remove the temporary input
  document.body.removeChild(input);
  
  // Show a toast or alert
  alert('Copied to clipboard: ' + text);
}

// Function to format numbers with commas
function formatNumber(num) {
  return num.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
}

// Function to truncate text with ellipsis
function truncateText(text, maxLength) {
  if (text.length <= maxLength) return text;
  return text.substr(0, maxLength) + '...';
}

// Function to show loading spinner
function showLoading(buttonElement, loadingText = 'Loading...') {
  const originalText = buttonElement.innerHTML;
  buttonElement.setAttribute('data-original-text', originalText);
  buttonElement.innerHTML = `<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> ${loadingText}`;
  buttonElement.disabled = true;
}

// Function to hide loading spinner
function hideLoading(buttonElement) {
  const originalText = buttonElement.getAttribute('data-original-text');
  buttonElement.innerHTML = originalText;
  buttonElement.disabled = false;
}

// Mining progress visualization
function updateMiningProgress() {
  const progressElement = document.getElementById('mining-progress');
  if (progressElement) {
    let progress = parseInt(progressElement.style.width || '0');
    if (progress < 100) {
      progress += Math.floor(Math.random() * 5) + 1; // Random progress
      progress = Math.min(progress, 100);
      progressElement.style.width = progress + '%';
      progressElement.innerText = progress + '%';
      
      // If mining is active, schedule next update
      if (progress < 100) {
        setTimeout(updateMiningProgress, 500);
      }
    }
  }
}

// Start mining progress animation if on mining page and mining is active
if (document.querySelector('.mining-active')) {
  updateMiningProgress();
}
